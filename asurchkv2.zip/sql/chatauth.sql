CREATE TABLE chatauth (
 chatsid varchar(50) COLLATE utf8_unicode_ci NOT NULL,
 stts varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci